<?php

require_once "esercizioOOP.php";

abstract class Quadrilatero extends Figure{

    abstract public function getArea();

    abstract public function getPerimetro();

}

?>