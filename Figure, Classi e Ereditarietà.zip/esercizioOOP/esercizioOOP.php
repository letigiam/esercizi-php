<?php

abstract class Figure{
  //funzione getArea astratta
    abstract public function getArea();

  //funzione getPerimetro astratta
  abstract public function getPerimetro();
  
}

?>